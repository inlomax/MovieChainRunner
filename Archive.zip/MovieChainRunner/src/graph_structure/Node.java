package graph_structure;

public class Node {
	private String data;
	
	public Node(String data) {
		this.data = data;
	}
	
	public String getData() {
		return this.data;
	}
}
